var router = require('express').Router();
var db = require('../../../lib/database')();
var multer = require ('multer');
var path = require('path');
var fileUpload = require('express-fileupload');
const bodyParser = require('body-parser')

router.use(bodyParser.json())
router.use(bodyParser.urlencoded({ extended: true }))
// var authMiddleware = require('../../auth/middlewares/auth');
//router.use(authMiddleware.hasAuthadmin);


var storage = multer.diskStorage({
    destination: function(req, file, callback) {
        callback(null, path.join(__dirname + '/uploads/'))
    },
    filename: function(req, file, callback) {
        console.log(file)
        callback(null,req.session.user.int_guestid + file.fieldname + '-' + Date.now() + path.extname(file.originalname))
    }
})



router.get('/', (req, res) => {
    res.render('guestwithsession/submittingforms/views/submittingforms');
});

router.get('/annointmentrequirements/:int_reservationid', (req, res) => {
    console.log(req.params.int_reservationid);
    req.session.user.int_reservationid = req.params.int_reservationid;
    console.log(req.session.user);
    res.render('guestwithsession/submittingforms/views/annointmentrequirements');
});


router.get('/baptismalrequirements/:int_reservationid', (req, res) => {
    console.log(req.params.int_reservationid);
    req.session.user.int_reservationid = req.params.int_reservationid;
    console.log(req.session.user);
    res.render('guestwithsession/submittingforms/views/baptismalrequirements');
});

router.get('/funeralrequirements/:int_reservationid', (req, res) => {
    console.log(req.params.int_reservationid);
    req.session.user.int_reservationid = req.params.int_reservationid;
    console.log(req.session.user);
    res.render('guestwithsession/submittingforms/views/funeralrequirements');
});

router.get('/massweddingrequirements/:int_reservationid', (req, res) => {
    console.log(req.params.int_reservationid);
    req.session.user.int_reservationid = req.params.int_reservationid;
    console.log(req.session.user);
    res.render('guestwithsession/submittingforms/views/massweddingrequirements');
});

router.get('/privateweddingrequirements/:int_reservationid', (req, res) => {
    req.session.user.int_reservationid = req.params.int_reservationid;
    var queryString1 =`SELECT * FROM tbl_event JOIN tbl_weddingevent ON tbl_event.int_eventid = tbl_weddingevent.int_eventid JOIN tbl_reservation ON tbl_weddingevent.int_eventid = tbl_reservation.int_eventid WHERE tbl_event.int_guestid = ? AND tbl_reservation.int_reservationid=${req.session.user.int_reservationid}`
    db.query(queryString1, [req.session.user.int_guestid], (err, results, fields) => {
        if (err) console.log(err);
    console.log('===========================================================');
    console.log(results);
    console.log('===========================================================');
    console.log(req.params.int_reservationid);
    console.log(req.session.user);
    console.log('REQ.SESSION.USERWEDD***********************************************************');
    req.session.userWedd=results;
    console.log(req.session.userWedd);
    console.log('***********************************************************');
    console.log('$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$');
    userWedd=req.session.userWedd;
    console.log(userWedd);
    console.log('$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$');
    req.session.userWeddd=results[0];
    console.log(req.session.userWeddd);
    console.log(req.session.userWeddd.bool_brideifpregnant);
    res.render('guestwithsession/submittingforms/views/privateweddingrequirements',{ privateWedding : req.session.userWedd });
});
});


router.use(fileUpload());


router.post('/annointmentrequirements/:int_reservationid', function(req, res) {      
                console.log(req.body, 'Body');
                console.log(req.files, 'Files');
                console.log(req.files.AnnointmentBirthCert);
                console.log(req.files.AnnointmentBirthCert.mv);
		let AnnointmentBirthCert = req.files.AnnointmentBirthCert;
        // var queryString = `INSERT INTO tbl_requirements(\`int_reservationid\`, \`varchar_requirements\`) VALUES (${req.session.user.int_reservationid},"${req.files.path}")`;
        AnnointmentBirthCert.mv(__dirname + '/uploads/' + req.session.user.int_reservationid+'-' + 'AnnointmentBirthCert'+ '-' + req.files.AnnointmentBirthCert.name + '-' + Date.now() + path.extname(req.files.AnnointmentBirthCert.name), function(err) {
		pathAnnointment = (__dirname + '/uploads/' + req.session.user.int_reservationid+'-' + 'AnnointmentsBirthCert'+ '-' + req.files.AnnointmentBirthCert.name + '-' + Date.now() + path.extname(req.files.AnnointmentBirthCert.name));
		        console.log(pathAnnointment);
		
		req.files.path = pathAnnointment
		var queryString = `INSERT INTO tbl_requirements(\`int_reservationid\`, \`varchar_requirements\`) VALUES (${req.session.user.int_reservationid}, "${req.files.path}")`;
		
		db.query(queryString,(err,results,fields)=>{
		if (err)
		res.status(500).send(err);
 
		return res.redirect('/guestwithsession/home');
		});
	});
});

router.post('/baptismalrequirements/:int_reservationid', function(req, res) {
                console.log(req.body, 'Body');
                console.log(req.files, 'Files');
                console.log(req.files.BaptismalBirtCert);
                console.log(req.files.BaptismalBirtCert.mv);
		let BaptismalBirtCert = req.files.BaptismalBirtCert;
        // var queryString = `INSERT INTO tbl_requirements(\`int_reservationid\`, \`varchar_requirements\`) VALUES (${req.session.user.int_reservationid},"${req.files.path}")`;

        BaptismalBirtCert.mv(__dirname + '/uploads/' + req.session.user.int_reservationid+'-' + 'BaptismalBirtCert'+ '-' + req.files.BaptismalBirtCert.name + '-' + Date.now() + path.extname(req.files.BaptismalBirtCert.name), function(err) {
		pathBaptismalBirtCert = (__dirname + '/uploads/' + req.session.user.int_reservationid+'-' + 'BaptismalBirtCert'+ '-' + req.files.BaptismalBirtCert.name + '-' + Date.now() + path.extname(req.files.BaptismalBirtCert.name));
		        console.log(pathBaptismalBirtCert);
		
		req.files.path = BaptismalBirtCert
		var queryString = `INSERT INTO tbl_requirements(\`int_reservationid\`, \`varchar_requirements\`) VALUES ( ${req.session.user.int_reservationid},"${req.files.path}")`;
		
		db.query(queryString,(err,results,fields)=>{
		if (err)
		res.status(500).send(err);
 
		return res.redirect('/guestwithsession/home');
		});
	});
});


router.post('/funeralrequirements/:int_reservationid', function(req, res) {
	
        //res.end('File is uploaded')
        console.log(req.body, 'Body');
        console.log(req.files, 'Files');
        console.log(req.files.FuneralBirthCert);
		
		//console.log(req.files.AnnointmentBirthCert.mv);
		let FuneralBirthCert = req.files.FuneralBirthCert;
		
            // var queryString = `INSERT INTO tbl_requirements(\`int_reservationid\`, \`varchar_requirements\`) VALUES (${req.session.user.int_reservationid},"${req.files.path}")`;

            FuneralBirthCert.mv(__dirname + '/uploads/' + req.session.user.int_reservationid+'-' + 'FuneralMassBirthCert'+ '-' + req.files.FuneralBirthCert.name + '-' + Date.now() + path.extname(req.files.FuneralBirthCert.name), function(err) {
		    pathFuneralBirthCert = (__dirname + '/uploads/' + req.session.user.int_reservationid +'-' + 'FuneralMassBirthCert'+ '-' + req.files.FuneralBirthCert.name + '-' + Date.now() + path.extname(req.files.FuneralBirthCert.name));
		
        console.log(pathFuneralBirthCert);
		
		req.files.path1 = pathFuneralBirthCert
		var queryString = `INSERT INTO tbl_requirements(\`int_reservationid\`, \`varchar_requirements\`) VALUES (${req.session.user.int_reservationid},"${req.files.path1}")`;
		
		    db.query(queryString,(err,results,fields)=>{
		
        let FuneralDeathCert = req.files.FuneralDeathCert;
        var queryString1 = `INSERT INTO tbl_requirements(\`int_reservationid\`, \`varchar_requirements\`) VALUES (${req.session.user.int_reservationid},"${req.files.path2}")`;
            FuneralDeathCert.mv(__dirname + '/uploads/' + req.session.user.int_reservationid + '-' + 'FuneralMassDeathCert' + '-' + req.files.FuneralDeathCert.name + '-' + Date.now() + path.extname(req.files.FuneralDeathCert.name), function(err) {
            pathFuneralDeathCert = (__dirname + '/uploads/' + req.session.user.int_reservationid +'-' + 'FuneralDeathCert'+ '-' + req.files.FuneralDeathCert.name + '-' + Date.now() + path.extname(req.files.FuneralDeathCert.name));
        
            console.log(req.files.FuneralDeathCertCert);
        
        req.files.path2 = pathFuneralDeathCert
		
		    db.query(queryString1,(err,results,fields)=>{
		    if (err)
		    res.status(500).send(err);	
 
		return res.redirect('/guestwithsession/home');
		});
	});
});
});       
});  


router.post('/massweddingrequirements/:int_reservationid', function(req, res) {
	
            console.log(req.body, 'Body');
            console.log(req.files, 'Files');
            console.log(req.files.MassWeddBaptismalCert);
            
            //console.log(req.files.AnnointmentBirthCert.mv);
            let MassWeddBaptismalCert = req.files.MassWeddBaptismalCert;

                MassWeddBaptismalCert.mv(__dirname + '/uploads/' + req.session.user.int_reservationid+'-' + 'MassWeddBaptismalCert'+ '-' + req.files.MassWeddBaptismalCert.name + '-' + Date.now() + path.extname(req.files.MassWeddBaptismalCert.name), function(err) {
            
                pathMassWeddBaptismalCert = (__dirname + '/uploads/' + req.session.user.int_reservationidint_reservationid +'-' + 'MassWeddBaptismalCert'+ '-' + req.files.MassWeddBaptismalCert.name + '-' + Date.now() + path.extname(req.files.MassWeddBaptismalCert.name));
            
            console.log(pathMassWeddBaptismalCert);
            
            req.files.path1 = pathMassWeddBaptismalCert
            var queryString = `INSERT INTO tbl_requirements(\`int_reservationid\`, \`varchar_requirements\`) VALUES (${req.session.user.int_reservationid},"${req.files.path1}")`;
            
                db.query(queryString,(err,results,fields)=>{
            
            console.log(req.files.MassWeddBaptismalCert);
            
            pathMassWeddConfirmationCert = (__dirname + '/uploads/' + req.session.user.int_reservationid +'-' + 'MassWeddConfirmationCert'+ '-' + req.files.MassWeddConfirmationCert.name + '-' + Date.now() + path.extname(req.files.MassWeddConfirmationCert.name));
            req.files.path2 = pathMassWeddConfirmationCert
            
            let MassWeddConfirmationCert = req.files.MassWeddConfirmationCert;
                var queryString1 = `INSERT INTO tbl_requirements(\`int_reservationid\`, \`varchar_requirements\`) VALUES (${req.session.user.int_reservationid},"${req.files.path2}")`;
                MassWeddConfirmationCert.mv(__dirname + '/uploads/' + req.session.user.int_reservationid + '-' + 'MassWeddConfirmationCert' + '-' + req.files.MassWeddConfirmationCert.name + '-' + Date.now() + path.extname(req.files.MassWeddConfirmationCert.name), function(err) {
                    
                db.query(queryString1,(err,results,fields)=>{
                if (err)
                res.status(500).send(err);	
            
            pathMassWeddBirthCert = (__dirname + '/uploads/' + req.session.user.int_reservationid +'-' + 'MassWeddBirthCert'+ '-' + req.files.MassWeddBirthCert.name + '-' + Date.now() + path.extname(req.files.MassWeddBirthCert.name));
            req.files.path3 = pathMassWeddBirthCert
            
            let MassWeddBirthCert = req.files.MassWeddBirthCert;
                var queryString1 = `INSERT INTO tbl_requirements(\`int_reservationid\`, \`varchar_requirements\`) VALUES (${req.session.user.int_reservationid},"${req.files.path3}")`;
                MassWeddBirthCert.mv(__dirname + '/uploads/' + req.session.user.int_reservationid + '-' + 'MassWeddBirthCert' + '-' + req.files.MassWeddBirthCert.name + '-' + Date.now() + path.extname(req.files.MassWeddBirthCert.name), function(err) {
            
                db.query(queryString1,(err,results,fields)=>{
                if (err)
                res.status(500).send(err);	
            
            pathMassWeddMarriageLicense = (__dirname + '/uploads/' + req.session.user.int_reservationid +'-' + 'MassWeddMarriageLicense'+ '-' + req.files.MassWeddMarriageLicense.name + '-' + Date.now() + path.extname(req.files.MassWeddMarriageLicense.name));
            req.files.path4 = pathMassWeddMarriageLicense
            
            let MassWeddMarriageLicense = req.files.MassWeddMarriageLicense;
                var queryString1 = `INSERT INTO tbl_requirements(\`int_reservationid\`, \`varchar_requirements\`) VALUES (${req.session.user.int_reservationid},"${req.files.path4}")`;
                MassWeddMarriageLicense.mv(__dirname + '/uploads/' + req.session.user.int_reservationid + '-' + 'MassWeddMarriageLicense' + '-' + req.files.MassWeddMarriageLicense.name + '-' + Date.now() + path.extname(req.files.MassWeddMarriageLicense.name), function(err) {
                    
                db.query(queryString1,(err,results,fields)=>{
                if (err)
                res.status(500).send(err);
            
            pathMassWeddingCENOMAR = (__dirname + '/uploads/' + req.session.user.int_reservationid +'-' + 'MassWeddingCENOMAR'+ '-' + req.files.MassWeddingCENOMAR.name + '-' + Date.now() + path.extname(req.files.MassWeddingCENOMAR.name));
            req.files.path5 = pathMassWeddingCENOMAR
            
            let MassWeddingCENOMAR = req.files.MassWeddingCENOMAR;
                var queryString1 = `INSERT INTO tbl_requirements(\`int_reservationid\`, \`varchar_requirements\`) VALUES (${req.session.user.int_reservationid},"${req.files.path5}")`;
                MassWeddingCENOMAR.mv(__dirname + '/uploads/' + req.session.user.int_reservationid + '-' + 'MassWeddingCENOMAR' + '-' + req.files.MassWeddingCENOMAR.name + '-' + Date.now() + path.extname(req.files.MassWeddingCENOMAR.name), function(err) {
            
                db.query(queryString1,(err,results,fields)=>{
                if (err)
                res.status(500).send(err);

            return res.redirect('/guestwithsession/home');
                                                });
                                            });
                                        });
                                    });       
                                });  
                            });
                        });
                    });
                });
            });
        });


    router.post('/privateweddingrequirements/:int_reservationid', function(req, res) {
	
        //res.end('File is uploaded')
        console.log(req.session.userWeddd.bool_brideifpregnant);
        console.log(req.body, 'Body');
        console.log(req.files, 'Files');
        console.log(req.files.PrivateWeddBaptismalCert);
		
		//console.log(req.files.AnnointmentBirthCert.mv);
		let PrivateWeddBaptismalCert = req.files.PrivateWeddBaptismalCert;

            PrivateWeddBaptismalCert.mv(__dirname + '/uploads/' + req.session.user.int_reservationid+'-' + 'PrivateWeddBaptismalCert'+ '-' + req.files.PrivateWeddBaptismalCert.name + '-' + Date.now() + path.extname(req.files.PrivateWeddBaptismalCert.name), function(err) {
		
		    pathPrivateWeddBaptismalCert = (__dirname + '/uploads/' + req.session.user.int_reservationidint_reservationid +'-' + 'PrivateWeddBaptismalCert'+ '-' + req.files.PrivateWeddBaptismalCert.name + '-' + Date.now() + path.extname(req.files.PrivateWeddBaptismalCert.name));
		
        console.log(pathPrivateWeddBaptismalCert);
		
		req.files.path1 = pathPrivateWeddBaptismalCert
		var queryString = `INSERT INTO tbl_requirements(\`int_reservationid\`, \`varchar_requirements\`) VALUES (${req.session.user.int_reservationid},"${req.files.path1}")`;
		
		    db.query(queryString,(err,results,fields)=>{
		
		console.log(req.files.PrivateWeddConfirmationCert);
        
        pathPrivateWeddConfirmationCert = (__dirname + '/uploads/' + req.session.user.int_reservationid +'-' + 'PrivateWeddConfirmationCert'+ '-' + req.files.PrivateWeddConfirmationCert.name + '-' + Date.now() + path.extname(req.files.PrivateWeddConfirmationCert.name));
        req.files.path2 = pathPrivateWeddConfirmationCert
		
        let PrivateWeddConfirmationCert = req.files.PrivateWeddConfirmationCert;
		    var queryString1 = `INSERT INTO tbl_requirements(\`int_reservationid\`, \`varchar_requirements\`) VALUES (${req.session.user.int_reservationid},"${req.files.path2}")`;
		    PrivateWeddConfirmationCert.mv(__dirname + '/uploads/' + req.session.user.int_reservationid + '-' + 'PrivateWeddConfirmationCert' + '-' + req.files.PrivateWeddConfirmationCert.name + '-' + Date.now() + path.extname(req.files.PrivateWeddConfirmationCert.name), function(err) {
				
		    db.query(queryString1,(err,results,fields)=>{
		    if (err)
            res.status(500).send(err);	
        
        pathPrivateWeddBirthCert = (__dirname + '/uploads/' + req.session.user.int_reservationid +'-' + 'PrivateWeddBirthCert'+ '-' + req.files.PrivateWeddBirthCert.name + '-' + Date.now() + path.extname(req.files.PrivateWeddBirthCert.name));
        req.files.path3 = pathPrivateWeddBirthCert
		
        let PrivateWeddBirthCert = req.files.PrivateWeddBirthCert;
		    var queryString1 = `INSERT INTO tbl_requirements(\`int_reservationid\`, \`varchar_requirements\`) VALUES (${req.session.user.int_reservationid},"${req.files.path3}")`;
		    PrivateWeddBirthCert.mv(__dirname + '/uploads/' + req.session.user.int_reservationid + '-' + 'PrivateWeddBirthCert' + '-' + req.files.PrivateWeddBirthCert.name + '-' + Date.now() + path.extname(req.files.PrivateWeddBirthCert.name), function(err) {
		
		    db.query(queryString1,(err,results,fields)=>{
		    if (err)
            res.status(500).send(err);	
        
        pathPrivateWeddMarriageLicense = (__dirname + '/uploads/' + req.session.user.int_reservationid +'-' + 'PrivateWeddMarriageLicense'+ '-' + req.files.PrivateWeddMarriageLicense.name + '-' + Date.now() + path.extname(req.files.PrivateWeddMarriageLicense.name));
        req.files.path4 = pathPrivateWeddMarriageLicense
		
        let PrivateWeddMarriageLicense = req.files.PrivateWeddMarriageLicense;
		    var queryString1 = `INSERT INTO tbl_requirements(\`int_reservationid\`, \`varchar_requirements\`) VALUES (${req.session.user.int_reservationid},"${req.files.path4}")`;
		    PrivateWeddMarriageLicense.mv(__dirname + '/uploads/' + req.session.user.int_reservationid + '-' + 'PrivateWeddMarriageLicense' + '-' + req.files.PrivateWeddMarriageLicense.name + '-' + Date.now() + path.extname(req.files.PrivateWeddMarriageLicense.name), function(err) {
				
		    db.query(queryString1,(err,results,fields)=>{
		    if (err)
            res.status(500).send(err);
        
        pathPrivateWeddCENOMAR = (__dirname + '/uploads/' + req.session.user.int_reservationid +'-' + 'PrivateWeddCENOMAR'+ '-' + req.files.PrivateWeddCENOMAR.name + '-' + Date.now() + path.extname(req.files.PrivateWeddCENOMAR.name));
        req.files.path5 = pathPrivateWeddCENOMAR
		
        let PrivateWeddCENOMAR = req.files.PrivateWeddCENOMAR;
		    var queryString1 = `INSERT INTO tbl_requirements(\`int_reservationid\`, \`varchar_requirements\`) VALUES (${req.session.user.int_reservationid},"${req.files.path5}")`;
		    PrivateWeddCENOMAR.mv(__dirname + '/uploads/' + req.session.user.int_reservationid + '-' + 'PrivateWeddCENOMAR' + '-' + req.files.PrivateWeddCENOMAR.name + '-' + Date.now() + path.extname(req.files.PrivateWeddCENOMAR.name), function(err) {
		
		    db.query(queryString1,(err,results,fields)=>{
		    if (err)
            res.status(500).send(err);
            // res.render('guestwithsession/submittingforms/views/submittingforms');
            // return res.redirect('/guestwithsession/home');
            validationPrivateWeddingPregnant();
        });


            function validationPrivateWeddingPregnant(){
                console.log('Nandito ako sa loob ng Validation Private Wedding Function Pregnant');
                console.log(req.session.userWeddd.bool_brideifpregnant);
                if(req.session.userWeddd.bool_brideifpregnant == 1){
                pathPrivateWeddClearanceChancery = (__dirname + '/uploads/' + req.session.user.int_reservationid +'-' + 'PrivateWeddClearanceChancery'+ '-' + req.files.PrivateWeddClearanceChancery.name + '-' + Date.now() + path.extname(req.files.PrivateWeddClearanceChancery.name));
                req.files.path6 = pathPrivateWeddClearanceChancery
                let PrivateWeddClearanceChancery = req.files.PrivateWeddClearanceChancery;
                var queryString1 = `INSERT INTO tbl_requirements(\`int_reservationid\`, \`varchar_requirements\`) VALUES (${req.session.user.int_reservationid},"${req.files.path6}")`;
                PrivateWeddClearanceChancery.mv(__dirname + '/uploads/' + req.session.user.int_reservationid + '-' + 'PrivateWeddClearanceChancery' + '-' + req.files.PrivateWeddClearanceChancery.name + '-' + Date.now() + path.extname(req.files.PrivateWeddClearanceChancery.name), function(err) {
                
                db.query(queryString1,(err,results,fields)=>{
                if (err)
                res.status(500).send(err);
                // return res.redirect('/guestwithsession/home');
                validationBrideReligion(); 
                });
                // return res.redirect('/guestwithsession/home');
                                                    });
                                                }
                else{
                    console.log('Di siya preggy function');
                    return res.redirect('/guestwithsession/home');
                    validationBrideReligion();
                }
                }

                function validationBrideReligion(){
                console.log('Nandito siya sa Function Bride ng Religion');
                    if(req.session.userWeddd.char_bridereligion =='Non-Catholic'){
                    pathPrivateWeddCertOfFreedomBride = (__dirname + '/uploads/' + req.session.user.int_reservationid +'-' + 'PrivateWeddCertOfFreedomBride'+ '-' + req.files.PrivateWeddCertOfFreedomBride.name + '-' + Date.now() + path.extname(req.files.PrivateWeddCertOfFreedomBride.name));
                    req.files.path7 = pathPrivateWeddCertOfFreedomBride
                    let PrivateWeddCertOfFreedomBride = req.files.PrivateWeddCertOfFreedomBride;
                    var queryString1 = `INSERT INTO tbl_requirements(\`int_reservationid\`, \`varchar_requirements\`) VALUES (${req.session.user.int_reservationid},"${req.files.path7}")`;
                    PrivateWeddCertOfFreedomBride.mv(__dirname + '/uploads/' + req.session.user.int_reservationid + '-' + 'PrivateWeddCertOfFreedomBride' + '-' + req.files.PrivateWeddCertOfFreedomBride.name + '-' + Date.now() + path.extname(req.files.PrivateWeddCertOfFreedomBride.name), function(err) {
                    
                    db.query(queryString1,(err,results,fields)=>{
                    if (err)
                    res.status(500).send(err); 
                    // validationGroomReligion();
                    // return res.redirect('/guestwithsession/home');
                                                            });
                                                        });
                    pathPrivateWeddPermissionMixedBride = (__dirname + '/uploads/' + req.session.user.int_reservationid +'-' + 'PrivateWeddPermissionMixedBride'+ '-' + req.files.PrivateWeddPermissionMixedBride.name + '-' + Date.now() + path.extname(req.files.PrivateWeddPermissionMixedBride.name));
                    req.files.path10 = pathPrivateWeddPermissionMixedBride
                    let PrivateWeddPermissionMixedBride = req.files.PrivateWeddPermissionMixedBride;
                    var queryString1 = `INSERT INTO tbl_requirements(\`int_reservationid\`, \`varchar_requirements\`) VALUES (${req.session.user.int_reservationid},"${req.files.path10}")`;
                    PrivateWeddPermissionMixedBride.mv(__dirname + '/uploads/' + req.session.user.int_reservationid + '-' + 'PrivateWeddPermissionMixedBride' + '-' + req.files.PrivateWeddPermissionMixedBride.name + '-' + Date.now() + path.extname(req.files.PrivateWeddPermissionMixedBride.name), function(err) {
                    
                    db.query(queryString1,(err,results,fields)=>{
                    if (err)
                    res.status(500).send(err); 
                    // validationGroomReligion();
                    // return res.redirect('/guestwithsession/home');
                                                            });
                                                        });
                    console.log('Non Catholic Bride');
                    validationGroomReligion();
                    }
                else{
                    console.log('Other religion basta hindi Non Catholic Bride');
                    validationGroomReligion();
                    return res.redirect('/guestwithsession/home');
                }
                }
                function validationGroomReligion(){
                        console.log('Nandito siya sa Function ng Groom Religion');
                        if(req.session.userWeddd.char_groomreligion =='Non-Catholic'){
                        pathPrivateWeddCertOfFreedomGroom = (__dirname + '/uploads/' + req.session.user.int_reservationid +'-' + 'PrivateWeddCertOfFreedomGroom'+ '-' + req.files.PrivateWeddCertOfFreedomGroom.name + '-' + Date.now() + path.extname(req.files.PrivateWeddCertOfFreedomGroom.name));
                        req.files.path8 = pathPrivateWeddCertOfFreedomGroom
                        let PrivateWeddCertOfFreedomGroom = req.files.PrivateWeddCertOfFreedomGroom;
                        var queryString1 = `INSERT INTO tbl_requirements(\`int_reservationid\`, \`varchar_requirements\`) VALUES (${req.session.user.int_reservationid},"${req.files.path8}")`;
                        PrivateWeddCertOfFreedomGroom.mv(__dirname + '/uploads/' + req.session.user.int_reservationid + '-' + 'PrivateWeddCertOfFreedomGroom' + '-' + req.files.PrivateWeddCertOfFreedomGroom.name + '-' + Date.now() + path.extname(req.files.PrivateWeddCertOfFreedomGroom.name), function(err) {
                        
                        db.query(queryString1,(err,results,fields)=>{
                        if (err)
                        res.status(500).send(err); 
                        // return res.redirect('/guestwithsession/home');
                        pathPrivateWeddPermissionMixedGroom = (__dirname + '/uploads/' + req.session.user.int_reservationid +'-' + 'PrivateWeddPermissionMixedGroom'+ '-' + req.files.PrivateWeddPermissionMixedGroom.name + '-' + Date.now() + path.extname(req.files.PrivateWeddPermissionMixedGroom.name));
                        req.files.path9 = pathPrivateWeddPermissionMixedGroom
                        let PrivateWeddPermissionMixedGroom = req.files.PrivateWeddPermissionMixedGroom;
                        var queryString1 = `INSERT INTO tbl_requirements(\`int_reservationid\`, \`varchar_requirements\`) VALUES (${req.session.user.int_reservationid},"${req.files.path9}")`;
                        PrivateWeddPermissionMixedGroom.mv(__dirname + '/uploads/' + req.session.user.int_reservationid + '-' + 'PrivateWeddPermissionMixedGroom' + '-' + req.files.PrivateWeddPermissionMixedGroom.name + '-' + Date.now() + path.extname(req.files.PrivateWeddPermissionMixedGroom.name), function(err) {
                        
                        db.query(queryString1,(err,results,fields)=>{
                        if (err)
                        res.status(500).send(err); 
                        return res.redirect('/guestwithsession/home');
                                                                });
                                                            });
                            });
                        });
                        }
                        else{
                        return res.redirect('/guestwithsession/home');
                        }
                        }
                                            
	                                    });
                                    });
                                });       
                            });  
                        });
                    });
                });
            });
        });
    });
        

module.exports = router;